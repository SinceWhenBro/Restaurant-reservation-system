# Capstone: Restaurant Reservation System Backend

This starter code for the backend of the capstone project in the Thinkful curriculum.

See [../README.md](../README.md) for detailed instructions.
